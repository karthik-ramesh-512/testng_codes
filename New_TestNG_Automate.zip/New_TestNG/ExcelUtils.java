package Parallel_Testing.New_TestNG;

import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
    
    // Returns a String[][] grid layout of your spreadsheet data
    public static String[][] getCellData() throws Exception {

        String projectPath = System.getProperty("user.dir");
        
        // Establishes connection to the file
        FileInputStream file = new FileInputStream(projectPath + "\\Orange_Hrm_Login.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet sheet = workbook.getSheet("Sheet1");

        int rowCount = sheet.getPhysicalNumberOfRows();
        int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
        
        // Defines grid size (skipping the 1st row header)
        String[][] data = new String[rowCount - 1][colCount];
        
        // DataFormatter cleanly extracts values without crashing on blank cells
        DataFormatter formatter = new DataFormatter();

        for (int row = 1; row < rowCount; row++) {
            for (int cell = 0; cell < colCount; cell++) {
                // Safely handles text, numbers, formulas, and nulls
                if (sheet.getRow(row) != null && sheet.getRow(row).getCell(cell) != null) {
                    data[row - 1][cell] = formatter.formatCellValue(sheet.getRow(row).getCell(cell));
                } else {
                    data[row - 1][cell] = ""; // Fallback value for completely empty blocks
                }
            }
        }

        // Clean up connections to prevent memory leaks
        workbook.close();
        file.close();

        return data; 
    }
}

package Parallel_Testing.New_TestNG;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Orange_Hrm_Login_Automate_Excel {
        
    // 1. Links this automation method to your data pipeline engine below
    @Test(dataProvider = "getLoginData")
    public void loginTest(String username, String password) throws Exception {
        
        System.out.println("Processing Credentials -> User: " + username + " | Pass: " + password);

        // Environment Setup
        WebDriverManager.chromedriver().setup();
        ChromeDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        try {
            // Open Application
            driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

            // Input Username
            WebElement user = driver.findElement(By.name("username"));
            user.sendKeys(username); 

            // Input Password
            WebElement pass = driver.findElement(By.name("password"));
            pass.sendKeys(password); 

            // Click Login Button
            WebElement login = driver.findElement(By.xpath("//button[@type='submit']"));
            login.click();

            // Dynamic wait strategy replacement placeholder (Used 3s freeze for simple demo flow)
            Thread.sleep(3000);
            
            String expectedURL = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";        
            String actualURL = driver.getCurrentUrl();
            
            // Verification step
            Assert.assertEquals(actualURL, expectedURL);
            System.out.println("Result: Login Executed Successfully for " + username);

        } catch (AssertionError e) {
            System.out.println("Result: Login Failed for " + username + " (Assertion Failure)");
            throw e; // Reports failures clearly back inside TestNG dashboard charts
        } catch (Exception e) {
            System.out.println("Result: System Exception encountered during run: " + e.getMessage());
            throw e;
        } finally {
            // Guarantees instances are killed cleanly regardless of test success or failure status
            driver.quit(); 
        }
    }

    // 2. Data Provider system maps the utility spreadsheet matrices over to your test cases
    @DataProvider(name = "getLoginData")
    public Object[][] getData() throws Exception {
        // Automatically translates String[][] from utility over into TestNG's required Object[][] syntax
        return ExcelUtils.getCellData(); 
    }
}

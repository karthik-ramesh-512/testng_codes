package Parallel_Testing.New_TestNG;

import java.io.File;
import java.time.Duration;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;


public class Sause_Demo_Assert  {
	
	@Test
    public void verification() throws Exception {

	ChromeDriver driver = null;
	
	

    try {

        // Setup Chrome Driver
        WebDriverManager.chromedriver().setup();

        // Chrome Options
        ChromeOptions options = new ChromeOptions();

        // Disable Notifications
        options.addArguments("--disable-notifications");

        // Disable Popup Blocking
        options.addArguments("--disable-popup-blocking");

        // Reduce Selenium Detection
        options.addArguments("--disable-blink-features=AutomationControlled");

        // Additional Real-Time Options
        options.addArguments("--start-maximized");
        options.addArguments("--incognito");
        options.addArguments("--disable-infobars");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-gpu");

        // Custom User Agent
        options.addArguments("user-agent=Mozilla/5.0 " + "(Windows NT 10.0; Win64; x64) " + "AppleWebKit/537.36 " + "(KHTML, like Gecko) "  + "Chrome/148.0.0.0 Safari/537.36");

        // Experimental Options
        options.setExperimentalOption("excludeSwitches",new String[]{"enable-automation"});

        options.setExperimentalOption("useAutomationExtension", false);

        // Launch Browser
        driver = new ChromeDriver(options);

        // Hide Automation Detection
        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript( "Object.defineProperty(navigator," + "'webdriver'," + "{get:()=>undefined})");

        // Browser Settings
        driver.manage().window().maximize();

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // Expected Title (INTENTIONALLY WRONG)
        String ExpectedTitle = "Account – Sauce Demo";

        System.out.println("Expected Title : " + ExpectedTitle);

        // Open Application
        driver.get("https://sauce-demo.myshopify.com/account/login");

        // Username
        WebElement username = driver.findElement(By.xpath("//input[@id='customer_email']"));

        username.sendKeys("Demosample1@gmail.com");

        Thread.sleep(1000);

        // Password
        WebElement password = driver.findElement(By.xpath("//input[@id='customer_password']"));

        password.sendKeys("DEMOSAMPLE");

        Thread.sleep(1000);

        // Login Button
        WebElement login = driver.findElement(By.xpath("//input[@value='Sign In']"));

        login.click();

        Thread.sleep(3000);

        // Actual Title
        String ActualTitle = driver.getTitle();

        System.out.println("Actual Title : " + ActualTitle);

        // Hard Assert
        Assert.assertEquals(ExpectedTitle, ActualTitle);

        System.out.println("Hard Assert Test Case Passed");

    }
    

    catch (AssertionError e) {

        System.out.println("Assertion Failed");

        // Screenshot Capture
        TakesScreenshot ts = (TakesScreenshot) driver;

        File source = ts.getScreenshotAs(OutputType.FILE);

        // Screenshot Location
        File destination = new File("C:\\Users\\rrkar\\OneDrive\\Desktop\\Testing\\TestNG\\LoginFailure_SausceDemo.png");

        FileUtils.copyFile(source, destination);

        System.out.println("Screenshot Captured");

        // Re-throw Assertion
        throw e;
    }

    finally {

        // Close Browser
        if(driver != null) {

            driver.quit();

            System.out.println(
                    "Browser Closed");
        }
    }
    
    }
}





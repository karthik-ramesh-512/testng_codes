package Parallel_Testing.New_TestNG;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Data_Provider {
	
	 public static void main(String[] args) throws IOException {

	        // ✅ Print project path (DEBUG – VERY IMPORTANT)
	        String projectPath = System.getProperty("user.dir");
	        System.out.println("Project Path is: " + projectPath);

	        // ✅ Excel file path
	        FileInputStream file = new FileInputStream(projectPath + "\\Name_List.xlsx");

	        // ✅ Load workbook
	        XSSFWorkbook workbook = new XSSFWorkbook(file);

	        // ✅ Get sheet
	        XSSFSheet sheet = workbook.getSheet("Sheet1");

	        // ✅ Get total rows
	        int totalRows = sheet.getLastRowNum();

	        // ✅ Get total cells
	        int totalCells = sheet.getRow(0).getLastCellNum();

	        System.out.println("Total Rows: " + totalRows);
	        System.out.println("Total Cells: " + totalCells);

	        // ✅ Loop through rows
	        for (int r = 0; r <= totalRows; r++) {

	            XSSFRow currentRow = sheet.getRow(r);

	            // ✅ Loop through cells
	            for (int c = 0; c < totalCells; c++) {

	                XSSFCell cell = currentRow.getCell(c);
	                System.out.print(cell.toString() + "   ");
	            }

	            System.out.println();
	        }

	        // ✅ Close resources
	        workbook.close();
	        file.close();
	    }

}

package Parallel_Testing.New_TestNG;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Sauce_Demo_Automate_Excel {
	
	@Test
    public void loginTest() throws Exception {
 		
 		 // Read Excel Data
        String[][] username = ExcelUtils.getCellData(1,0);

        String[][] password = ExcelUtils.getCellData(1,1);

        System.out.println("Username: " + username);
        System.out.println("Password: " + password);

        // Browser Launch
        WebDriverManager.chromedriver().setup();

        ChromeDriver driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // Open Application
        driver.get("https://sauce-demo.myshopify.com/account/login");

        // Username
        WebElement user = driver.findElement(By.xpath("//input[@id='customer_email']"));

        user.sendKeys(username);

        // Password
        WebElement pass = driver.findElement(By.xpath("//input[@id='customer_password']"));

        pass.sendKeys(password);

        // Login Button
        WebElement login = driver.findElement(By.xpath("//input[@value='Sign In']"));

        login.click();

        Thread.sleep(1000);
        
        String ExpectedURL = "https://sauce-demo.myshopify.com/account?analytics_trace_id=b485f796-f554-4605-99b7-ff7d833d8c18";        
        String ActualURL = driver.getCurrentUrl();
		Assert.assertEquals(ExpectedURL, ActualURL);
        System.out.println("Login Executed");

        driver.quit();
}


}

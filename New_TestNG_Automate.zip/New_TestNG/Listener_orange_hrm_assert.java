package Parallel_Testing.New_TestNG;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class Listener_orange_hrm_assert implements ITestListener {
	
	  @Override
	    public void onTestStart(ITestResult tr) {

	        System.out.println("Test case is started");
	    }

	    @Override
	    public void onTestSuccess(ITestResult tr) {

	        System.out.println("Test case succeed");
	    }

	    @Override
	    public void onTestFailure(ITestResult tr) {

	        System.out.println("Test case is a failure");
	    }

	    @Override
	    public void onTestSkipped(ITestResult tr) {

	        System.out.println("Test case is skipped");
	    }
	
	

}

package Parallel_Testing.New_TestNG;

public class App {
  public static void main(String[] args) {
    System.out.println("Hello World!");
  }
}

package Parallel_Testing.New_TestNG;

import java.time.Duration;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

	public class Parallel_Thread1 {
		
		@Test(threadPoolSize = 10, invocationCount = 10)
		public void method2() throws InterruptedException
		{
			System.out.println("Method Two: " +Thread.currentThread().getId());
			WebDriverManager.chromedriver().setup();
			ChromeDriver driver = new ChromeDriver();
			Thread.sleep(3000);
			driver.get("https://www.flipkart.com");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			driver.quit();
		}

	}



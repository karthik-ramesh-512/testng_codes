package Parallel_Testing.New_TestNG;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;


public class Chrome_Test2 {
	
	@Test
    public void flipkartTest() throws Exception {

        System.out.println("Flipkart Test Thread ID : "+ Thread.currentThread().getId());
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://www.flipkart.com");
        System.out.println("Flipkart Title : "+ driver.getTitle());
        Thread.sleep(2000);
        driver.quit();
    }


}

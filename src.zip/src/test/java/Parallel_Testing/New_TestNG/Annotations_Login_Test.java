package Parallel_Testing.New_TestNG;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Annotations_Login_Test {
	
	WebDriver driver;

    // Runs only once before class
    @BeforeClass
    public void setupBrowser() {

        System.out.println("Opening Browser");

        WebDriverManager.chromedriver().setup();

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

    // Runs before every test method
    @BeforeMethod
    public void openApplication() {

        System.out.println("Opening Application");

        driver.get("https://sauce-demo.myshopify.com/account/login");
    }

    // Test Case 1
    @Test(priority = 1)
    public void loginTest() {

        System.out.println("Login Test Started");

        WebElement username = driver.findElement(By.xpath("//input[@id='customer_email']"));

        username.sendKeys("Demosample1@gmail.com");

        WebElement password = driver.findElement(By.xpath("//input[@id='customer_password']"));

        password.sendKeys("DEMOSAMPLE");

        WebElement loginButton = driver.findElement(By.xpath("//input[@value='Sign In']"));

        loginButton.click();

        String actualTitle = driver.getTitle();

        String expectedTitle = "Account – Sauce Demo";

        Assert.assertEquals(actualTitle, expectedTitle);

        System.out.println("Login Successful");
    }

    // Test Case 2
    @Test(priority = 2)
    public void forgotPasswordLink() {

        System.out.println("Forgot Password Test Started");

        WebElement forgotPassword = driver.findElement(By.xpath("//a[normalize-space()='Forgot your password?']"));

        forgotPassword.click();

        String currentUrl = driver.getCurrentUrl();

        Assert.assertTrue(currentUrl.contains("account1"));

        System.out.println("Forgot Password Link Working");
    }

    // Runs after every test method
    @AfterMethod
    public void clearCookies() {

        System.out.println("Clearing Cookies");

        driver.manage().deleteAllCookies();
    }

    // Runs once after class
    @AfterClass
    public void closeBrowser() {

        System.out.println("Closing Browser");

        driver.quit();
    }

}

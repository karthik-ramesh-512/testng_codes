package Parallel_Testing.New_TestNG;

import java.io.File;
import java.time.Duration;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import io.github.bonigarcia.wdm.WebDriverManager;


public class orange_hrm_assert {
	
	@Test()
	public void verification() throws Exception { 
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("--disable-blink-features=AutomationControlled");
        //Captcha blocker
		options.setExperimentalOption("excludeSwitches",new String[]{"enable-automation"});
        options.setExperimentalOption("useAutomationExtension",false);
        ChromeDriver driver = new ChromeDriver(options);       
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("Object.defineProperty(navigator, 'webdriver', " + "{get: () => undefined})");
		//WebDriver driver = new ChromeDriver(options);
		//ChromeDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		String ExpectedTitle = "OrangeHRM1";
		System.out.println("Expected Title: " +ExpectedTitle);		
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        
        WebElement username = driver.findElement(By.name("username"));
		username.sendKeys("Admin");
		Thread.sleep(1000);
		
		WebElement password = driver.findElement(By.name("password"));
		password.sendKeys("admin123");
		Thread.sleep(1000);
		
		WebElement login = driver.findElement(By.xpath("//button[normalize-space()='Login']"));
		login.click();
		Thread.sleep(1000);
		
		//HardAssert
		//String ActualTitle = driver.getTitle();
		//System.out.println("Actual Title: " +ActualTitle);
		//Assert.assertEquals(ExpectedTitle, ActualTitle);
		//System.out.println("Hard Assert Test Case is Passed.");
		//driver.quit();
		
		String ActualTitle = driver.getTitle();

        System.out.println("Actual Title: " + ActualTitle);

        try {

            Assert.assertEquals(ExpectedTitle, ActualTitle);
            System.out.println("Hard Assert Test Case Passed");

        }

        catch (AssertionError e) {

            System.out.println("Assertion Failed");            
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            File destination = new File("C:\\Users\\rrkar\\OneDrive\\Desktop\\Testing\\TestNG\\LoginFailure.png");
            FileUtils.copyFile(source, destination);
            System.out.println("Screenshot Captured");
            throw e;
        }

        driver.quit();

    }

	
	
	
	@Test()
	public void verification2() throws InterruptedException { 
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		String ExpectedTitle = "OrangeHRM";
		System.out.println("Expected Title: " +ExpectedTitle);		
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        
        WebElement username = driver.findElement(By.name("username"));
		username.sendKeys("Admin");
		Thread.sleep(1000);
		
		WebElement password = driver.findElement(By.name("password"));
		password.sendKeys("admin123");
		Thread.sleep(1000);
		
		WebElement login = driver.findElement(By.xpath("//button[normalize-space()='Login']"));
		login.click();
		Thread.sleep(1000);
		
		//SoftAssert
		String ActualTitle = driver.getTitle();
		SoftAssert Assertion = new SoftAssert();
		System.out.println("Actual Title: " +ActualTitle);
		Assertion.assertEquals(ExpectedTitle, ActualTitle);
		System.out.println("Soft Assert Test Case is Passed.");
		driver.quit();
		Assertion.assertAll();
	}

}

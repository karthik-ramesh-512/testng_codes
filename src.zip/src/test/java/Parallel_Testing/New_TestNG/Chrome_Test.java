package Parallel_Testing.New_TestNG;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;


public class Chrome_Test {
	
	@Test
    public void amazonTest() throws Exception {

        System.out.println("Amazon Test Thread ID : "+ Thread.currentThread().getId());
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://www.amazon.in");
        System.out.println("Amazon Title : "+ driver.getTitle());
        Thread.sleep(2000);
        driver.quit();
    }


}

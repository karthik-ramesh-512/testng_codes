package Parallel_Testing.New_TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Soft_and_Hard_Assest {
	
	@Test(priority = 1)
	public void softassert1() { 
		SoftAssert Assertion = new SoftAssert();
		System.out.println("Test one is started. ");
		Assertion.assertEquals(12, 12);
		System.out.println("My name is SoftAssert");
		Assertion.assertAll();
	}
	
	@Test(priority = 2)
	public void hardassert1() { 
		System.out.println("Test two is started. ");
		Assert.assertEquals(12, 12);
		System.out.println("My name is HardAssert");
	}

}
